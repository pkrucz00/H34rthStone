package GameEngine;

public enum BoardDivision {
    BOARD_BOT,
    BOARD_PLAYER,
    HAND_PLAYER
}
