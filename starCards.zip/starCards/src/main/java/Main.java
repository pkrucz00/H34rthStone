import GUI.WelcomeFrame;

import javax.print.DocFlavor;

public class Main {
    public static void main(String[] args){
        new WelcomeFrame();
    }
}
